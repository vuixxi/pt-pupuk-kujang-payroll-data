function formatNumber(num) {
   return Math.floor(num).toLocaleString("id-ID");
}


